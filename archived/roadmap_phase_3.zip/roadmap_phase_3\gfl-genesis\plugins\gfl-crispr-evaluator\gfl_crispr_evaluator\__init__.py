"""
GFL Plugin for CRISPR Evaluation Orchestration
"""
