"""
GFL Plugin for Off-Target Scoring
"""
