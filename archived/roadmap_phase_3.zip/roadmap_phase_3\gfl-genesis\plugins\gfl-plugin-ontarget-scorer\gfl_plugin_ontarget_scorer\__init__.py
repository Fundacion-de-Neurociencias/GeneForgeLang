"""
GFL Plugin for On-Target Scoring
"""
